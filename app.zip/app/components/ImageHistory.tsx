"use client";

import { useState, useEffect } from "react";
import { TrashIcon, ArrowDownTrayIcon, EyeIcon } from "@heroicons/react/24/outline";
import { saveAs } from "file-saver";

interface HistoryItem {
  id: string;
  originalImage: string;
  generatedImage: string;
  style: string;
  roomType: string;
  timestamp: Date;
  filename: string;
}

interface ImageHistoryProps {
  onImageSelect?: (item: HistoryItem) => void;
}

export default function ImageHistory({ onImageSelect }: ImageHistoryProps) {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Load history from localStorage
    const savedHistory = localStorage.getItem('designHistory');
    if (savedHistory) {
      const parsed = JSON.parse(savedHistory);
      setHistory(parsed.map((item: any) => ({
        ...item,
        timestamp: new Date(item.timestamp)
      })));
    }
  }, []);

  const addToHistory = (item: Omit<HistoryItem, 'id' | 'timestamp'>) => {
    const newItem: HistoryItem = {
      ...item,
      id: Date.now().toString(),
      timestamp: new Date()
    };
    
    const updatedHistory = [newItem, ...history].slice(0, 20); // Keep last 20 items
    setHistory(updatedHistory);
    localStorage.setItem('designHistory', JSON.stringify(updatedHistory));
  };

  const removeFromHistory = (id: string) => {
    const updatedHistory = history.filter(item => item.id !== id);
    setHistory(updatedHistory);
    localStorage.setItem('designHistory', JSON.stringify(updatedHistory));
  };

  const downloadImage = (imageUrl: string, filename: string) => {
    fetch(imageUrl)
      .then(response => response.blob())
      .then(blob => {
        saveAs(blob, `${filename}_redesigned.png`);
      })
      .catch(error => console.error('Download failed:', error));
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('designHistory');
  };

  return (
    <>
      {/* History Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 right-4 z-50 bg-indigo-600 text-white p-3 rounded-full shadow-lg hover:bg-indigo-700 transition-colors"
      >
        <EyeIcon className="w-5 h-5" />
        {history.length > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {history.length}
          </span>
        )}
      </button>

      {/* History Panel */}
      {isOpen && (
        <div className="fixed inset-0 z-40 bg-black bg-opacity-50" onClick={() => setIsOpen(false)}>
          <div 
            className="fixed right-0 top-0 h-full w-96 bg-white shadow-xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Design History</h2>
                {history.length > 0 && (
                  <button
                    onClick={clearHistory}
                    className="text-red-600 hover:text-red-800 text-sm"
                  >
                    Clear All
                  </button>
                )}
              </div>

              {history.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No designs yet</p>
              ) : (
                <div className="space-y-4">
                  {history.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4 hover:bg-gray-50">
                      <div className="flex space-x-3">
                        <img
                          src={item.originalImage}
                          alt="Original"
                          className="w-16 h-16 object-cover rounded"
                        />
                        <img
                          src={item.generatedImage}
                          alt="Generated"
                          className="w-16 h-16 object-cover rounded"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {item.filename}
                          </p>
                          <p className="text-xs text-gray-500">
                            {item.style} • {item.roomType}
                          </p>
                          <p className="text-xs text-gray-400">
                            {item.timestamp.toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex justify-end space-x-2 mt-3">
                        <button
                          onClick={() => onImageSelect?.(item)}
                          className="text-indigo-600 hover:text-indigo-800 text-sm"
                        >
                          View
                        </button>
                        <button
                          onClick={() => downloadImage(item.generatedImage, item.filename)}
                          className="text-green-600 hover:text-green-800"
                        >
                          <ArrowDownTrayIcon className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => removeFromHistory(item.id)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <TrashIcon className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// Export the addToHistory function for use in other components
export { type HistoryItem };
